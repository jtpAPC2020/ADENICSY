<?php
session_start();
session_destroy();
?>
<script language="javascript">
    document.location = "login.php";
</script>