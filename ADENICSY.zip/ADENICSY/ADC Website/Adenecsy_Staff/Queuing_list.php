<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <link href= "https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Apelo Dental Clinic Staff</title>
    <link rel="stylesheet" href="bootstrap.css">
	<link rel="stylesheet" href="style.css">
</head>

<body>
        <!-- Navbar --> 
    <!-- navbar-expand-lg is breakpoint -->
    <nav class="navbar navbar-expand-lg bg-primary navbar-dark pt-2 fixed-top">
        <div class="container">
            <a href="#" class="navbar-brand fs-3">Apelo Dental Clinic</a>
            <!--button below is what appears when navbar collapses-->
            <button 
                class="navbar-toggler" 
                type="button" 
                data-bs-toggle="collapse" 
                data-bs-target="#navmenu"
            >
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navmenu">
                <ul class="navbar-nav ms-auto fs-5"> <!-- ms-auto is to make the nav tab on right side -->
                    <li class="nav-item">
                        <a href="Staff.php" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="Payment.php" class="nav-link">Payment</a>
                    </li>
                    <li class="nav-item">
                        <a href="Queuing.html" class="nav-link">Queuing</a>
                    </li>
                    <li class="nav-item">
                        <a href="#facilities" class="nav-link">Log out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!--Time and Button to Queu List-->
    <div class="container pt-5 mt-5">
    <div class="row justify-content-start ">
        <div class="col-1" style="border-style: solid; background-color: #E9C5FB;">
            Time:
            </div>
        <div id="Clock" class="col-2" style="border-style: solid; background-color: #E9C5FB; ">
            00:00:00
        </div>
    <button type="submit" class="col-4 offset-5 list box-shadow:2px 4px #888888;" >Go to Queuing List</button>
    </div>
    <script src= script.js></script>
    <div class="container p-3 mt-3">
        <!-- flex is used to contain items inside container in rows-->
        <div>
            <div class="d-sm-flex align-items-center justify-content-around text-primary ">
                <h1 id="welcome">Current Number Being Serve</h1>
            </div>
    </div>
    <!--current number being served-->
    <section class="p-3 text-center text-sm-start">
    <div class="container p-1 mt-1">
    <!-- flex is used to contain items inside container in rows-->
        <div class="row justify-content-around">
        <!-- <div id="qNow" class="col-lg-2 col-m-2 col-s-2 col-xs-2 box" onclick="queue.next()">
        <div id="qNowNum">0</div>
        </div>
        </div>
        <button type="submit" class="list box-shadow:2px 4px #888888; p-2 mt-3 row mx-auto"  id="qAll" onclick="queue.add" >Next Number</button>
            </div> -->
            <div id="qNow"  class="col-lg-2 col-m-2 col-s-2 col-xs-2 box" onclick="queue.next()">
             <div id="qNowNum">0</div>
             <div id="qNowTitle">NOW</div>
            </div>
        <!-- (B) TOTAL IN QUEUE -->
             <div id="qAll"  class="col-lg-2 col-m-2 col-s-2 col-xs-2 box" onclick="queue.add()">
                <div id="qAllNum">0</div>
                <div id="qAllTitle">Avail</div>
            </div>
        </div>
        <div>
            <div class= "d-sm-flex align-items-center justify-content-around text-primary border-top-10 border-dark">
                <h1 id="welcome">Schedule of Doctors</h1>
            </div>
            <script src= for_number.js></script>
    </div>
</section>
    <div class="container">
        <div class="row" style="border-style: solid; background-color: #E9C5FB;">
    <!-- flex is used to contain items inside container in rows-->
    <?php
     $hostName = "localhost";
     $userName = "root";
    $password = "";
    $databaseName = "d_name";
    $conn = new mysqli($hostName, $userName, $password, $databaseName);
    // Check connection
   if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
   }
        $sql = "SELECT code, fullname FROM `doctor`;";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table><tr><th>Name</th><th>Code</th></tr>";
            // output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr><td></td>".$row["fullname"] ."<td></td></tr>".$row["code"] ;
            }
            echo "</table>";
        } else {
            echo "0 results";
        }
        $conn->close();

    ?>
    </div>
    <div class="wrapper">
</body>
</html>