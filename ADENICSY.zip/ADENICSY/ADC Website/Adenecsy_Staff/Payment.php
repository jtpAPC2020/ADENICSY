      <!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <link href= "https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Apelo Dental Clinic Staff</title>
    <link rel="stylesheet" href="bootstrap.css">
</head>
<body style = "background-color: #F7EBFD;">
    <!-- Navbar --> 
    <!-- navbar-expand-lg is breakpoint -->
    <nav class="navbar navbar-expand-lg bg-primary navbar-dark pt-2 fixed-top">
        <div class="container">
            <a href="#" class="navbar-brand fs-3">Apelo Dental Clinic</a>
            <!--button below is what appears when navbar collapses-->
            <button 
                class="navbar-toggler" 
                type="button" 
                data-bs-toggle="collapse" 
                data-bs-target="#navmenu"
            >
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navmenu">
                <ul class="navbar-nav ms-auto fs-5"> <!-- ms-auto is to make the nav tab on right side -->
                    <li class="nav-item">
                        <a href="Staff.php" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="#Payment.php" class="nav-link">Payment</a>
                    </li>
                    <li class="nav-item">
                        <a href="Queuing_list.php" class="nav-link">Queuing</a>
                    </li>
                    <li class="nav-item">
                        <a href="#facilities" class="nav-link">Log out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
      <!--Payment-->
       <section id="payment" class ="p-5 text-center text-sm-start">
        <div class ="container p-5 mt-5"></div>
            <!--flex is used to contain items inside container in rows-->
            <div class="id-sm flex align-items-center justify-content-around">
                <div class="d-sm-flex align-items-center justify-content-around">
                    <h1 style="font-size:2cm; color: #461873;">Payment Records</h1>

                </div>
                <div class="d-sm-flex align-items-center justify-content-around">
                    <form action="patient_search.php">
                        <input  style ="  width:500px;
                        height:50px;
                        border-radius:20px;
                        border: none;
                        padding: 0 10px 0 29px;
                        box-shadow:3px 5px #888888;" type="text" placeholder="Search patient..." name="search">
                        <button style ="  width:100px;
                        height:50px;
                        border-radius:20px;
                        border: none;
                        background-color: #E9C5FB;
                        margin-left: 10px;
                        box-shadow:1px 3px #888888;"  type="submit">Search</button>
                      </form>
                </div>
            </div>
        </div>
    </section>
</body>