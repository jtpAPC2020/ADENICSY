<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <link href= "https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Apelo Dental Clinic Staff</title>
    <link rel="stylesheet" href="bootstrap.css">
   
</head>
<body style = "background-color: #F7EBFD;">
    <!-- Navbar --> 
    <!-- navbar-expand-lg is breakpoint -->
    <nav class="navbar navbar-expand-lg bg-primary navbar-dark pt-2 fixed-top">
        <div class="container">
            <a href="#" class="navbar-brand fs-3">Apelo Dental Clinic</a>
            <!--button below is what appears when navbar collapses-->
            <button 
                class="navbar-toggler" 
                type="button" 
                data-bs-toggle="collapse" 
                data-bs-target="#navmenu"
            >
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navmenu">
                <ul class="navbar-nav ms-auto fs-5"> <!-- ms-auto is to make the nav tab on right side -->
                    <li class="nav-item">
                        <a href="#home" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="Payment.php" class="nav-link">Payment</a>
                    </li>
                    <li class="nav-item">
                        <a href="Queuing_list.php" class="nav-link">Queuing</a>
                    </li>
                    <li class="nav-item">
                        <a href="#Setting.html" class="nav-link">Settings</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
        <!-- Home -->
        <section id="home" class="p-5 text-center text-sm-start">
            <div class="container p-5 mt-5">
                <!-- flex is used to contain items inside container in rows-->
                <div>
                    <div class="d-sm-flex align-items-center justify-content-around">
                        <h1 id="welcome">Welcome!</h1>

                    </div>
                    <img class=" figure-img p-5 img-fluid w-50 ps-5 d-none d-block d-md-block" src="undrawAnimations\undraw_medicine.svg" alt="Doctors">
                </div>
            </div>
        </section>
        </body>