<?php

$server = "localhost";
$username = "root";
$password = "";
$dbname = "loginsystem";

$conn = mysqli_connect($server, $username, $password, $dbname);
